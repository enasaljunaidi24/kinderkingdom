package com.example.kinderkingdom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class forgetpassword1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_forgetpassword1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    public void continuee(View view) {
        // المفروض يرجعهم حسب هم شو اختاروا من الويلكم بيج
        Intent continuee=new Intent(forgetpassword1.this, welcomeepage.class);
        startActivity(continuee);
    }

    public void searchbyemail(View view) {
        Intent searchbyemail =new Intent(forgetpassword1.this, forgetpassword2.class);
        startActivity(searchbyemail);
    }
}