package com.example.kinderkingdom;

import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class page1 extends AppCompatActivity {
    TextSpeaker speaker;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_page1);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        speaker = new TextSpeaker(this);
        TextView title = findViewById(R.id.textView3);
        //شبك الصوت مع الجملة
        title.setOnClickListener(v -> {
            speaker.speak(title.getText().toString());
        });

    }
    @Override
    protected void attachBaseContext(Context newBase) {
        String lang = newBase.getSharedPreferences("settings", MODE_PRIVATE)
                .getString("lang", "en");

        Configuration config = newBase.getResources().getConfiguration();
        config.setLocale(new Locale(lang));

        Context context = newBase.createConfigurationContext(config);
        super.attachBaseContext(context);
    }


    public void SignUp(View view) {
        Intent page1tosignup =new Intent(page1.this, signup.class);
        startActivity(page1tosignup );

    }

    public void LogIn(View view) {
        Intent page1tologin =new Intent(page1.this, login.class);
        startActivity(page1tologin );
    }

    public void setting(View view) {
        Intent setting=new Intent(page1.this, SettingsActivity.class);
        startActivity(setting );

    }
}