package com.example.kinderkingdom;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class academicinformation extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_academicinformation);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
    public void classschedule2(View view) {
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        classschedule classschedule = new classschedule();
        ft.replace(R.id.linearcon,classschedule);
        ft.commit();

    }

    public void homework2(View view) {
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        homework homework = new homework();
        ft.replace(R.id.linearcon,homework);
        ft.commit();
    }

    public void attendanceandabsence2(View view) {
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        attendancendabsenceofstudents attendanceandabsence = new attendancendabsenceofstudents ();
        ft.replace(R.id.linearcon,  attendanceandabsence );
        ft.commit();
    }

    public void Interaction2(View view) {
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        interaction Interaction2  = new interaction ();
        ft.replace(R.id.linearcon, Interaction2 );
        ft.commit();
    }

    public void examschedule(View view) {
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        examsschedule examschedule = new examsschedule ();
        ft.replace(R.id.linearcon, examschedule);
        ft.commit();
    }

    public void marks2(View view) {
        FragmentManager fm=getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        marks marks2 = new marks ();
        ft.replace(R.id.linearcon, marks2);
        ft.commit();
    }
}