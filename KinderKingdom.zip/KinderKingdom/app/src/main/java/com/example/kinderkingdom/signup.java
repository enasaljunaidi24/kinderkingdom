package com.example.kinderkingdom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class signup extends AppCompatActivity {

    Button Signup;
    EditText email, password, phone;
    TextView resultogphone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Signup = findViewById(R.id.SignUp);
        email = findViewById(R.id.EnterEmailss);
        password = findViewById(R.id.EnterPasswordss);
        // استدعاء Firebase
        //mAuth → Firebase Authentication المسؤول عن التسجيل وتسجيل الدخول عبر
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        //mDatabase →  Realtime Database نقطة البداية للتعامل مع قاعدة بيانات
        DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference(); // جذر قاعدة البيانات

        Signup.setOnClickListener(v -> {
            //trim() → يزيل الفراغات الزائدة
            String Email = email.getText().toString().trim();
            String Password = password.getText().toString().trim();


            if(Email.isEmpty() || Password.isEmpty() ){
                Toast.makeText(signup.this, "يرجى تعبئة كل الحقول", Toast.LENGTH_SHORT).show();
                return;
            }

            // تسجيل المستخدم
            mAuth.createUserWithEmailAndPassword(Email, Password)
                    .addOnCompleteListener(task -> {
                        if(task.isSuccessful()){
                            FirebaseUser user = mAuth.getCurrentUser();
                            if(user != null){
                                String userId = user.getUid();
                                // خزّن فقط البيانات المهمة (password لا تخزن)
                                User newUser = new User(Email);
                                mDatabase.child("Users").child(userId).setValue(newUser)
                                        .addOnCompleteListener(dbTask -> {
                                            if(dbTask.isSuccessful()){
                                                Toast.makeText(signup.this, "تم التسجيل وحفظ البيانات بنجاح", Toast.LENGTH_SHORT).show();
                                                // الانتقال لصفحة أخرى إذا أردت
                                                 startActivity(new Intent(signup.this, welcomeepage.class));
                                            } else {
                                                Toast.makeText(signup.this, "خطأ بحفظ البيانات: " + dbTask.getException().getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        });
                            }
                        } else {
                            Toast.makeText(signup.this, "خطأ بالتسجيل: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });
        });
    }

    // كلاس المستخدم لتخزين البيانات في Firebase
    public static class User {
        public String email;
        public String phone;

        // كونستركتور فارغ مطلوب من Firebase
        public User(String email) {}

        public User(String email, String phone){
            this.email = email;
            this.phone = phone;
        }



//        Signup.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String Email = email.getText().toString();
//                String Password = password.getText().toString();
//                String Phone =phone.getText().toString();
//                Spinner spphone = (Spinner) findViewById(R.id.myarrays);
//                resultogphone=findViewById(R.id.resultogphones);
//
//
//                if (!Email.isEmpty() && !Password.isEmpty()) {
//                    if (!Phone.isEmpty()) {
//                        try {
//                            // التحقق أن الرقم عبارة عن أرقام فقط
//                            int Phone2 = Integer.parseInt(Phone);
//
//                            // جلب رمز الدولة من السبنر
//                            String phonenum = String.valueOf(spphone.getSelectedItem());
//                            resultogphone.setText(phonenum);
//
//                            // إذا كل شيء تمام → انتقل للصفحة التالية
//                            Intent signuptowelcome = new Intent(signup.this, welcomeepage.class);
//                            startActivity(signuptowelcome );
//
//                        } catch (NumberFormatException e) {
//                            e.printStackTrace();
//                            Toast.makeText(signup.this, "رقم الهاتف غير صالح", Toast.LENGTH_SHORT).show();
//                        }
//                    } else {
//                        Toast.makeText(signup.this, "Please Enter Your Phone", Toast.LENGTH_SHORT).show();
//                    }
//                } else {
//                    Toast.makeText(signup.this, "Please Enter Your Email And Password", Toast.LENGTH_SHORT).show();
//                }
//
//
//            }
//        });
//

    }



        public void forget(View view) {
            Intent forget = new Intent(signup.this, forgetpassword1.class);
            startActivity(forget);
        }

        public void RememberMe(View view) {
            Toast.makeText(this, "Information Saved", Toast.LENGTH_SHORT).show();
        }
    }


