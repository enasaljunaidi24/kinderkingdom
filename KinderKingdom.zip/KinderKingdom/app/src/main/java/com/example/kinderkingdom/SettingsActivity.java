package com.example.kinderkingdom;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Switch;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SettingsActivity extends AppCompatActivity {

    Button btnChangeLang;
    Switch switchVoice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnChangeLang = findViewById(R.id.btnChangeLang);
        switchVoice = findViewById(R.id.switchVoice);

        // Load saved voice status
        boolean voiceEnabled = getSharedPreferences("settings", MODE_PRIVATE)
                .getBoolean("voice_enabled", false);
        switchVoice.setChecked(voiceEnabled);

        switchVoice.setOnCheckedChangeListener((btn, isChecked) -> {
            getSharedPreferences("settings", MODE_PRIVATE)
                    .edit()
                    .putBoolean("voice_enabled", isChecked)
                    .apply();
        });

        // Change Language Button
        btnChangeLang.setOnClickListener(v -> {
            String lang = getSharedPreferences("settings", MODE_PRIVATE)
                    .getString("lang", "en");

            String newLang = lang.equals("en") ? "ar" : "en";

            getSharedPreferences("settings", MODE_PRIVATE)
                    .edit()
                    .putString("lang", newLang)
                    .apply();

            new LanguageManager(this).setLanguage(newLang);

            recreate(); // refresh page
        });
    }
}

