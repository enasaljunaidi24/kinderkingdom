package com.example.kinderkingdom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class managers extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_managers);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }

    public void securitybutton(View view) {
        Intent  securitybutton=new Intent(managers.this, security.class);
        startActivity(securitybutton);
    }

    public void helpersbutton(View view) {
        Intent  helpersbutton=new Intent(managers.this, helpers.class);
        startActivity(helpersbutton);
    }


    public void driversbutton(View view) {
        Intent  driverbutton=new Intent(managers.this, drivers.class);
        startActivity(driverbutton);
    }


    public void studentsbutton(View view) {
        Intent studentsbutton=new Intent(managers.this, studentmychild.class);
        startActivity(studentsbutton);
    }

    public void teachersbutton(View view) {
        Intent teachersbutton=new Intent(managers.this, teachers2.class);
        startActivity(teachersbutton);
    }

    public void bustour(View view) {
        Intent bustour=new Intent(managers.this, bustour.class);
        startActivity(bustour);
    }

    public void messagebutton(View view) {
        Intent messagebutton =new Intent(managers.this,messagesofmanagers.class);
        startActivity(messagebutton);
    }

    public void feedbackandnotes(View view) {
        Intent FeedbackandNotes =new Intent(managers.this, feedbackandnotesofmanagers.class);
        startActivity(FeedbackandNotes);
    }
}