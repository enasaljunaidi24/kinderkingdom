package com.example.kinderkingdom;

//import static com.example.kinderkingdom.R.id.kinder;
import android.annotation.SuppressLint;
import android.content.Intent;
import com.google.firebase.analytics.FirebaseAnalytics;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import android.widget.TextView;
//import android.view.animation.DecelerateInterpolator;
//import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private FirebaseAnalytics mFirebaseAnalytics; // تعريف المتغير


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


    }



    public void kinder(View view) {
        Intent kinder =new Intent(MainActivity.this, page1.class);
        startActivity(kinder);
    }
}


