package com.example.kinderkingdom;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.FirebaseApp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class login extends AppCompatActivity {
    FirebaseFirestore db;

    Button Login;
    EditText email, password;
    TextView orangesignup, resultogphonel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // تهيئة Firebase
        FirebaseApp.initializeApp(this);
        db = FirebaseFirestore.getInstance();
        Login = findViewById(R.id.LogInl);
        email = findViewById(R.id.EnterEmailll);
        password = findViewById(R.id.EnterPasswordll);
        orangesignup = findViewById(R.id.textView6);

        // زر تسجيل الدخول

        Login.setOnClickListener(v -> { String Email = email.getText().toString().trim();
            String Password = password.getText().toString().trim();

            Log.d("DBG_LOGIN", "User pressed login. Email raw='" + email.getText().toString() + "'");
            Log.d("DBG_LOGIN", "Trimmed Email='" + Email + "' Password='" + Password + "'");

            if (Email.isEmpty() || Password.isEmpty()) {
                Toast.makeText(this, "ادخل جميع الحقول", Toast.LENGTH_SHORT).show();
                return;
            }
            String id="2026100@kinderkingdom.edu.jo";

//

            db.collection("children").document(id)
                    .get()
                    .addOnCompleteListener(task -> {
                        if (!task.isSuccessful()) {
                            Exception e = task.getException();
                            Log.e("DBG_LOGIN", "Task failed: ", e);
                            Toast.makeText(this, "فشل استعلام: " + (e!=null? e.getMessage() : "unknown"), Toast.LENGTH_LONG).show();
                            return;
                        }

                        DocumentSnapshot document = task.getResult();
                        if (document == null) {
                            Log.w("DBG_LOGIN", "DocumentSnapshot is null for: " + Email);
                            Toast.makeText(this, "لم يصل رد من القاعدة", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        Log.d("DBG_LOGIN", "Document exists? " + document.exists());
                        Log.d("DBG_LOGIN", "Document id (from snapshot): " + document.getId());
                        Log.d("DBG_LOGIN", "Document data keys: " + (document.getData() != null ? document.getData().keySet().toString() : "no data"));

                        if (!document.exists()) {
                            Toast.makeText(this, "الايميل غير موجود", Toast.LENGTH_SHORT).show();
                            return;
                        }

                        String dbPass = document.getString("password");
                        Log.d("DBG_LOGIN", "dbPass='" + dbPass + "'");

                    });
        });
    }
    // دالة SignUptext خارج onCreate
    public void SignUptext(View view) {
        Intent SignUptexttosignup = new Intent(login.this, signup.class);
        startActivity(SignUptexttosignup);
    }

} // نهاية الكلاس
