package com.example.kinderkingdom;

import android.content.Context;
import android.speech.tts.TextToSpeech;

import java.util.Locale;

public class TextSpeaker {

    private TextToSpeech tts;
    private Context context;

    public TextSpeaker(Context context) {
        this.context = context;

        tts = new TextToSpeech(context, status -> {
            if (status == TextToSpeech.SUCCESS) {

                // Read current language
                String lang = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
                        .getString("lang", "en");

                if (lang.equals("ar"))
                    tts.setLanguage(new Locale("ar"));
                else
                    tts.setLanguage(Locale.US);

            }
        });
    }

    public void speak(String text) {

        boolean enabled = context.getSharedPreferences("settings", Context.MODE_PRIVATE)
                .getBoolean("voice_enabled", false);

        if (!enabled) return;

        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
    }
}
