package com.example.kinderkingdom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class teachers2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_teachers2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }
    public void teachersinformation(View view) {
        Intent teachersinformation =new Intent(teachers2.this, teacherinformation.class);
        startActivity(teachersinformation);
    }
    public void studentsinformation(View view) {
        Intent studentinformationpage =new Intent(teachers2.this, studentinformationpage.class);
        startActivity( studentinformationpage);
    }

    public void academicnformation(View view) {
        Intent  academicnformation =new Intent(teachers2.this, academicinformation.class);
        startActivity( academicnformation);
    }

    public void Messages(View view) {
        Intent Messages =new Intent(teachers2.this, messagesofteachers.class);
        startActivity(Messages);
    }

    public void bustour(View view) {
        Intent bustour =new Intent(teachers2.this, bustour.class);
        startActivity(bustour);
    }

    public void FeedbackandNotes(View view) {
        Intent FeedbackandNotes =new Intent(teachers2.this, feedbackandnotesofteachers.class);
        startActivity(FeedbackandNotes);
    }



    public void dailymenuu(View view) {
        Intent dailymenuu =new Intent(teachers2.this,  dailymenu.class);
        startActivity( dailymenuu);
    }


    public void attendanceandabsenceofteachers(View view) {
        Intent attendanceandabsenceofteachers =new Intent(teachers2.this,  attendanceandabsenceofteachers.class);
        startActivity( attendanceandabsenceofteachers);

    }

    public void work(View view) {
        Intent work =new Intent(teachers2.this,  work.class);
        startActivity(work);
    }


}