package com.example.kinderkingdom;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class welcomeepage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_welcomeepage);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
//        TextView textView = findViewById(R.id.welcome);
//
//
//        textView.post(() -> {
//            // من اليمين إلى اليسار (تدرّج أفقي)
//            Shader shader = new LinearGradient(
//                    0, 0, textView.getWidth(), 0,
//                    new int[]{
//                            Color.parseColor("#FF69B4"), // زهري
//                            Color.parseColor("#1E90FF"), // أزرق
////                            Color.parseColor("#FFA500") , // برتقالي
//                            Color.parseColor("#FF69B4") // زهري
//
//                    },
//                    null,
//                    Shader.TileMode.CLAMP);
//
//            textView.getPaint().setShader(shader);
//            textView.invalidate();
//        });
//        TextView textView = findViewById(R.id.Welcome);
//        Shader shader = new LinearGradient(
//                0, 0, 0, textView.getTextSize(),
//                new int[]{
//                        Color.parseColor("#FF69B4"), // زهري
//                        Color.parseColor("#1E90FF"), // أزرق سماوي
//                        Color.parseColor("#FFA500")  // برتقالي
//                },
//                null,
//                Shader.TileMode.CLAMP);
//
//        textView.getPaint().setShader(shader);

    }

    public void welcome(View view) {
        Intent welcometoteachers =new Intent(welcomeepage.this, managers.class);
        startActivity(welcometoteachers);
    }
//
//    public void employee(View view) {
//        Intent employee =new Intent(welcomeepage.this, teachers.class);
//        startActivity(employee);
//    }
//
//    public void studentss(View view) {
//        Intent studentss =new Intent(welcomeepage.this, students.class);
//        startActivity(studentss);
//    }
//
//    public void managements(View view) {
//        Intent managements =new Intent(welcomeepage.this, managers.class);
//        startActivity(managements);
//    }

}