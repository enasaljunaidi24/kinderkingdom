package com.example.kinderkingdom;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class studentmychild extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_studentmychild);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void information(View view) {
        Intent studentinformationpage =new Intent(studentmychild.this, studentinformationpage.class);
        startActivity( studentinformationpage);
    }
    public void teachersinformation(View view) {
        Intent teachersinformation =new Intent(studentmychild.this, teacherssubjectsinfo.class);
        startActivity(teachersinformation );
    }

    public void academicnformation(View view) {
        Intent  academicnformation =new Intent(studentmychild.this, academicinformation.class);
        startActivity( academicnformation);
    }

    public void Messages(View view) {
        Intent Messages =new Intent(studentmychild.this, messageofstudents.class);
        startActivity(Messages);
    }

    public void bustour(View view) {
        Intent bustour =new Intent(studentmychild.this, bustour.class);
        startActivity(bustour);
    }

    public void FeedbackandNotes(View view) {
        Intent FeedbackandNotes =new Intent(studentmychild.this, feedbackandnotesofstudents.class);
        startActivity(FeedbackandNotes);
    }

    public void RegistrationandPayment(View view) {
        Intent  RegistrationandPayment=new Intent(studentmychild.this, registrationandpayment.class);
        startActivity(RegistrationandPayment);
    }

    public void dailymenuu(View view) {
        Intent  dailymenuu =new Intent(studentmychild.this,  dailymenu.class);
        startActivity( dailymenuu);
    }
}